Documentation is available on http://www.your-freedom.net/
